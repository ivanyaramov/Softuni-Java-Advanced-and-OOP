package companyRoster;

public class Department {
    public String name;
    public double sum=0;
    public int count=1;
    public Department(String name){
        this.name=name;
    }
}
