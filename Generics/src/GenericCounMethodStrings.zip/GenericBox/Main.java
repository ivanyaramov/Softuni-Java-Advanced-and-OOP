package GenericBox;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int a = Integer.parseInt(scanner.nextLine());
        List<String> list= new ArrayList<>();
       Box<String> box=new Box<>(list,scanner.nextLine());
       box.add(scanner,a);
        System.out.println(box.count(scanner));

    }
}
