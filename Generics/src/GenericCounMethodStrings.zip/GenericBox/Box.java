package GenericBox;

import java.util.List;
import java.util.Scanner;

public class Box<T extends Comparable<T>> {
    List<T> list;
public Box(List<T> list ,T element){
    this.list=list;
    list.add(element);
}
public void add(Scanner scanner,int n) {
    for (int i = 0; i < n - 1; i++){
        list.add((T)scanner.nextLine());
    }

}

public int count(Scanner scanner){
    T last=(T) scanner.nextLine();
    int br=0;
    for(T cur:this.list){
        if(last.compareTo(cur)<0){
            br++;
        }
    }
    return br;
}
}
