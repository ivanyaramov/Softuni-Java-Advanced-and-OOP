package CustomList;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
CustomList<String> customList=new CustomList<String>();
        Scanner scanner = new Scanner(System.in);
String line = scanner.nextLine();
while(!line.equals("END")){
    String[] arr=line.split(" ");
    String command=arr[0];
    if(command.equals("Add")){
        customList.add(arr[1]);
    }
    if(command.equals("Remove")){
        customList.remove(Integer.parseInt(arr[1]));
    }
    if(command.equals("Contains")){
        System.out.println(customList.contains(arr[1]));
    }
    if(command.equals("Swap")){
        customList.swap(Integer.parseInt(arr[1]),Integer.parseInt(arr[2]));

    }
    if(command.equals("Greater")){
        System.out.println(customList.countGreaterThan(arr[1]));
    }
    if(command.equals("Max")){
        System.out.println(customList.getMax());
    }
    if(command.equals("Min")){
        System.out.println(customList.getMin());
    }
    if(command.equals("Print")){
        customList.print();
    }






    line=scanner.nextLine();
}

    }
}
