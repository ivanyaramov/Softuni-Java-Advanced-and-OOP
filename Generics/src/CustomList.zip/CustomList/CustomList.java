package CustomList;

import java.util.ArrayList;
import java.util.List;

public class CustomList <T extends  Comparable<T>> {
    List<T> list;
    public CustomList(){
        this.list=new ArrayList<>();
    }
    void add(T element){
        this.list.add(element);
    }
    void remove(int index){
        this.list.remove(index);
    }
    boolean contains(T element){
        for(T cur:this.list){
            if(cur.compareTo(element)==0){
                return true;
            }
        }
        return false;
    }

    void swap(int index1,int index2){
        T cur= list.get(index1);
        list.set(index1,list.get(index2));
        list.set(index2,cur);
    }
    int countGreaterThan(T element){
        int br=0;
        for(T cur:this.list){
            if(cur.compareTo(element)>0){
                br++;
            }
        }
        return br;
    }

    T getMax(){
        T max=list.get(0);
        for(T cur:this.list){
            if(cur.compareTo(max)>0){
                max=cur;
            }
        }
        return max;

    }

    T getMin(){
        T min=list.get(0);
        for(T cur:this.list){
            if(cur.compareTo(min)<0){
                min=cur;
            }
        }
        return min;

    }

    void print(){
        for(T cur:list){
            System.out.println(cur);
        }
    }



}
