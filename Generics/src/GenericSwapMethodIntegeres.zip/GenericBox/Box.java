package GenericBox;

import java.util.ArrayList;
import java.util.List;

public class Box<T> {
List<T> list;
public Box(){
    this.list=new ArrayList<>();
}
public void swap(int ind1,int ind2){
    T help=this.list.get(ind1);
    this.list.set(ind1,this.list.get(ind2));
    this.list.set(ind2,help);
}
    @Override
    public String toString() {
    StringBuilder build=new StringBuilder();
    for(int i=0;i<this.list.size();i++){
        build.append(this.list.get(i).getClass().getName());
        build.append(": ");
        build.append(this.list.get(i));
        build.append(System.lineSeparator());
    }
        return build.toString();
    }
}
