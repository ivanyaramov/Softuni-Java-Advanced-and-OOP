package GenericBox;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int a = Integer.parseInt(scanner.nextLine());
        Box<Integer> box=new Box<>();
        for(int i=0;i<a;i++){
            int num = Integer.parseInt(scanner.nextLine());
            box.list.add(num);
        }
        String[] arr=scanner.nextLine().split(" ");
        int ind1=Integer.parseInt(arr[0]);
        int ind2=Integer.parseInt(arr[1]);
        box.swap(ind1,ind2);
        System.out.println(box.toString());

    }
}
