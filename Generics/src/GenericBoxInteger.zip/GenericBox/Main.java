package GenericBox;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int a = Integer.parseInt(scanner.nextLine());
        for(int i=0;i<a;i++){

            int num= Integer.parseInt(scanner.nextLine());
            Box<Integer> box1=new Box<>(num);
            System.out.println(box1.toString());
        }

    }
}
