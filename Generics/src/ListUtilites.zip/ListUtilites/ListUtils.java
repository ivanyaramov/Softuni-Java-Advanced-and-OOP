package ListUtilites;

import java.util.List;
import java.util.Optional;

public class ListUtils<T extends Comparable<T>> {
    public static <T extends Comparable<T>> T getMin(List<T> list){
        if(list.isEmpty()){
            throw new IllegalArgumentException();
        }
        T min=list.get(0);
        for(T cur:list){
if(cur.compareTo(min)<0){
    min=cur;
}
        }
        return min;
    }

    public static <T extends Comparable<T>> T getMax(List<T> list){
        if(list.isEmpty()){
            throw new IllegalArgumentException();
        }
        T max=list.get(0);
        for(T cur:list){
            if(cur.compareTo(max)>0){
                max=cur;
            }
        }
        return max;
    }
}
