package GenericBox;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int a = Integer.parseInt(scanner.nextLine());
        for(int i=0;i<a;i++){
            String line = scanner.nextLine();
            Box<String> box1=new Box<>(line);
            System.out.println(box1.toString());
        }

    }
}
