package GenericBox;

public class Box<T> {
T element;
public Box(T element){
    this.element=element;
}
    @Override
    public String toString() {
StringBuilder sb = new StringBuilder();
sb.append(element.getClass().getName());
sb.append(": ");
sb.append(this.element);


        return sb.toString();
    }
}
