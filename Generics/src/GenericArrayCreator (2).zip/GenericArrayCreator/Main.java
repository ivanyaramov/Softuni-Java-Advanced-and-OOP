package GenericArrayCreator;


public class Main {
    public static void main(String[] args) {
        String[] strings= ArrayCreator.create(10,"a");

        Integer[] integers= ArrayCreator.create(Integer.class,10,2);


    }
}
