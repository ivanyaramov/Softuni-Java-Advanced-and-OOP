package CustomList;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Sorter {
    public static <T extends Comparable> void sort(CustomList<String> list){
        list.list= list.list.stream()
                .sorted((p1,p2)->p1.compareTo(p2))
        .collect(Collectors.toList());

    }

}
