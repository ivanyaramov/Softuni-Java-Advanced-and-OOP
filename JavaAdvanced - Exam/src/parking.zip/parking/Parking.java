package parking;

import java.util.ArrayList;
import java.util.List;

public class Parking {
    private String type;
    private int capacity;
    private List<Car> data;

    public Parking(String type, int capacity) {
        this.type = type;
        this.capacity = capacity;
        this.data=new ArrayList<>();
    }
    public void add(Car car){
        if(this.data.size()+1<=this.capacity);
        this.data.add(car);
    }
    public boolean remove(String manufacturer, String model){
        for(int i=0;i<this.data.size();i++){
            if(this.data.get(i).getManufacturer().equals(manufacturer) && this.data.get(i).getModel().equals(model)){
                this.data.remove(i);
                return true;
            }
        }
        return false;
    }
    public Car getLatestCar(){
        if(this.data.size()==0){
            return null;
        }
        return this.data.get(this.data.size()-1);
    }

    public Car getCar(String manufacturer,String model){

        for(int i=0;i<this.data.size();i++){
            if(this.data.get(i).getManufacturer().equals(manufacturer) && this.data.get(i).getModel().equals(model)){
               return this.data.get(i);

            }
        }
        return null;
    }
    public int getCount(){
        return this.data.size();
    }
    public String getStatistics(){
        StringBuilder s= new StringBuilder(String.format("The cars are parked in %s:", this.type));
     for(Car car : this.data){
         s.append(System.lineSeparator());
         s.append(car.toString());
     }
        return s.toString();
    }

}
