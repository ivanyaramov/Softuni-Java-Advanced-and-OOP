package classroom;

import java.util.ArrayList;
import java.util.List;

public class Classroom {
   public int capacity;
    public List<Student> students;
    public Classroom(int capacity){
        this.capacity=capacity;
        this.students =new ArrayList<>();
    }

    public int getCapacity() {
        return capacity;
    }

    public List<Student> getStudents() {
        return students;
    }
    public int getStudentCount(){
        return this.students.size();
    }

    public String registerStudent(Student student){
        String line="";
        boolean isStudent=false;
        for(Student cur:this.students){
            if(cur.getFirstName().equals(student.getFirstName()) && cur.getLastName().equals(student.getLastName())){
                isStudent=true;
                break;
            }
        }
        if(isStudent){
            line="Student is already in the classroom";
        }
        else if(this.students.size()+1<=this.capacity){
            this.students.add(student);

                line = String.format("Added student %s %s", student.firstName, student.lastName);

            }
        else{
            if(line.equals("")) {
                line = "No seats in the classroom";
            }
        }
        return line;
    }

    public String dismissStudent(Student student){
        String line="";
        boolean isStudent=false;
        int index=-1;
        for(int i = 0; i<this.students.size(); i++){
            Student cur=this.students.get(i);
            if(cur.getFirstName().equals(student.getFirstName()) && cur.getLastName().equals(student.getLastName())){
                isStudent=true;
                index=i;
                break;
            }
        }
        if(isStudent){
            this.students.remove(index);
            line=String.format("Removed student %s %s",student.getFirstName(),student.getLastName());
        }
        else{
            line="Student not found";
        }
        return line;
    }
    public String getSubjectInfo(String subject) {
        boolean hasStudent = false;
        StringBuilder sb = new StringBuilder();
        for (Student student : students) {
            if (student.getBestSubject().equals(subject)) {

                hasStudent = true;

                break;
            }

        }
        if (hasStudent) {
            sb.append(String.format("Subject: %s%n", subject)).append("Students:");
            for (Student student : students) {
                if (student.getBestSubject().equals(subject)) {
                    sb.append(String.format("%n%s %s", student.getFirstName(), student.getLastName()));

                }

            }
            return sb.toString();
        }
        return "No students enrolled for the subject";
    }
    public Student getStudent(String firstName,String lastName){

        for(Student cur:this.students){
            if(cur.getFirstName().equals(firstName) && cur.getLastName().equals(lastName)){
                return cur;

            }
        }
       return null;
    }

    public String getStatistics(){
        StringBuilder build=new StringBuilder();
        build.append(String.format("Classroom size: %d",this.students.size()));
        for(Student cur:this.students){
            build.append(System.lineSeparator());
            build.append("==Student: ");
            build.append(cur.toString());
        }
        return build.toString();
    }


    
}
