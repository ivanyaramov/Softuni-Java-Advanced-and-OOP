import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class Lake implements Iterable<Integer> {
    List<Integer> list;

    public Lake(Integer... list) {
        this.list = Arrays.asList(list);
    }
    @Override
    public Iterator<Integer> iterator() {
        return new Frog();
    }
public class Frog implements Iterator<Integer> {
    int counter=0;
    boolean bool=false;

    @Override
    public boolean hasNext() {
        if(counter>=list.size()&&!bool){
            bool=true;
            counter=1;
        }
        return counter<list.size();

    }

    @Override
    public Integer next() {
        Integer a=list.get(counter);
        counter+=2;
        return a;
    }
}
}
