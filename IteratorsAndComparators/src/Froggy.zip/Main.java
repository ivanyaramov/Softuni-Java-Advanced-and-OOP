import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args)  {
        Scanner scanner = new Scanner(System.in);
        String a = scanner.nextLine();
        Integer[] arr=Arrays.stream(a.split(", "))
                .mapToInt(Integer::parseInt)
                .boxed()
                .toArray(Integer[]::new);
        Lake lake=new Lake(arr);
        String end = scanner.nextLine();
        StringBuilder build=new StringBuilder();
        if(end.equals("END")){
            for(Integer cur:lake){
                build.append(cur+", ");
            }
        }
        build.delete(build.length()-2,build.length());
        System.out.println(build);
    }
}