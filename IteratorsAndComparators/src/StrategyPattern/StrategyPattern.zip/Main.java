package StrategyPattern;

import StrategyPattern.CompareByAge;
import StrategyPattern.CompareByName;
import StrategyPattern.Person;

import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class Main {
    public static void main(String[] args)  {
        Scanner scanner = new Scanner(System.in);
        int n=Integer.parseInt(scanner.nextLine());
        Set<Person> set1 =new TreeSet<>(new CompareByName());
        Set<Person> set2 =new TreeSet<>(new CompareByAge());
        for(int i=0;i<n;i++){
            String a = scanner.nextLine();
            String[] arr=a.split(" ");
            Person person=new Person(arr[0],Integer.parseInt(arr[1]));
            set1.add(person);
            set2.add(person);
        }
        set1.forEach(System.out::println);
        set2.forEach(System.out::println);
    }
}