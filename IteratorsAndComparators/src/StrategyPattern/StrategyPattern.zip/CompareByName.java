package StrategyPattern;

import java.util.Comparator;

public class CompareByName implements Comparator<Person> {

    @Override
    public int compare(Person o1, Person o2) {
        if(o1.name.length()>o2.name.length()){
            return 1;
        }
        else if(o1.name.length()<o2.name.length()){
            return -1;
        }
        else{
            char c1=o1.name.toLowerCase().charAt(0);
            char c2=o2.name.toLowerCase().charAt(0);
            return c1-c2;
        }
    }
}