import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String a = scanner.nextLine();
        List<String> list=Arrays.stream(a.split(" "))
                .collect(Collectors.toList());
        list.remove(0);
        ListyIterator listyIterator= new ListyIterator(list);
         a = scanner.nextLine();
        while(!a.equals("END")){

            if(a.equals("Move")){
                System.out.println(listyIterator.Move());
            }
            if(a.equals("Print")){
               listyIterator.Print();
            }
            if(a.equals("HasNext")){
                System.out.println(listyIterator.HasNext());
            }
            if(a.equals("PrintAll")){
                for(String s: listyIterator.list){
                    System.out.print(s+" ");
                }
                System.out.println();
            }
            a=scanner.nextLine();
        }
    }
    }


