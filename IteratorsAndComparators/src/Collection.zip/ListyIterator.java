import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.stream.Collectors;

public class ListyIterator implements Iterable<String>{
List<String> list;
int index;

    public ListyIterator(List<String> list) {
        this.list = list;
        index=0;
    }
   public boolean Move(){
      if(index+1>=list.size()){
          return false;
      }
      index++;
      return true;
   }
    public boolean HasNext(){
        if(index+1>=list.size()){
            return false;
        }
        return true;
    }
    public void Print(){
        if(list.size()==0){
            System.out.println("Invalid Operation!");
        }
        else{
            System.out.println(list.get(index));
        }
    }

    @Override
    public Iterator<String> iterator() {

        return new Iterator<String>() {
            int counter=0;
            @Override
            public boolean hasNext() {
                return counter<list.size();
            }

            @Override
            public String next() {
                return list.get(index++);
            }
        };
    }
}
