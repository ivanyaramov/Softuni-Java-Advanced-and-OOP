import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
Book bookOne=new Book("a",2004,"George Orwell");
Book bookThree=new Book("a",2003);
Book bookTwo=new Book("a",2005,"Dhoroty","Robert");
List<Book> books=new ArrayList<>();
books.add(bookOne);
books.add(bookTwo);
books.add(bookThree);
Library library=new Library(bookOne,bookTwo,bookThree);
books.sort(new BookComparator());
for(Book book:books){
    System.out.println(book.getTitle()+book.getYear());
}

        if (bookOne.compareTo(bookTwo) > 0) {
            System.out.println(String.format("%s is before %s", bookOne, bookTwo));
        } else if (bookOne.compareTo(bookTwo) < 0) {
            System.out.println(String.format("%s is before %s", bookTwo, bookOne));
        } else {
            System.out.println("Books are equal");
        }
    }
    }


