import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args)  {
        Scanner scanner = new Scanner(System.in);
        List<Person> list= new ArrayList<>();
       while(true){
           String a = scanner.nextLine();
           if(a.equals("END")){
               break;
           }
           String[] arrString=a.split(" ");
           Person person=new Person(arrString[0],Integer.parseInt(arrString[1]),arrString[2]);
           list.add(person);
       }
        int index = Integer.parseInt(scanner.nextLine());
       Person p=list.get(index-1);
       int same=0;

       for(Person cur:list){
           if(cur.compareTo(p)==0){
               same++;
           }
       }
       if(same==1){
           System.out.println("No matches");
       }
       else {
           System.out.printf("%d %d %d",same,list.size() - same, list.size());
       }

    }
}