import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class StackIterator implements Iterable<Integer> {
    List<Integer> list;
    public StackIterator(){
        this.list=new ArrayList<>();
    }
    public void Push(int... arr){
        for(int cur:arr){
            list.add(cur);
        }
    }
    public int Pop(){
        if(list.size()==0){
            System.out.println("No elements");
            return 0;
        }
        else {
            int t=list.get(list.size()-1);
             list.remove(list.size() - 1);
             return t;
        }}

    @Override
    public Iterator<Integer> iterator() {
        return new Iterator<Integer>(){

            int counter=list.size()-1;
            @Override
            public boolean hasNext() {
                return counter>=0;
            }

            @Override
            public Integer next() {
                return list.get(counter--);
            }
        };
    }
}
