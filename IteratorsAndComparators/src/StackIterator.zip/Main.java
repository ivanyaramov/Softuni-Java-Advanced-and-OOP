import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String a = scanner.nextLine();
        StackIterator stackIterator=new StackIterator();
        while(!a.equals("END")){

            if(a.equals("Pop")) {
                stackIterator.Pop();
            }
                if(a.contains("Push")){
                    String onlyNums=a.substring(5);
                    int[] arr= Arrays.stream(onlyNums.split(", ")).
                            mapToInt(Integer::parseInt)
                            .toArray();
                    stackIterator.Push(arr);
                }

            a=scanner.nextLine();
        }
        for(int i=0;i<2;i++) {
            for (int cur : stackIterator) {
                System.out.println(cur);
            }
        }
    }
    }


